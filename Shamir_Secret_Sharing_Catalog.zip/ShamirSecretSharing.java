import java.math.BigInteger;
import java.util.*;

public class ShamirSecretSharing {
    public static void main(String[] args) {
        // You can read from input1.json and input2.json here manually (without using libraries)
        // Hardcode the values or parse manually for simplicity as libraries are not allowed

        // Example structure (just a placeholder, complete manually)
        // Map<Integer, BigInteger> x = new HashMap<>();
        // Map<Integer, BigInteger> y = new HashMap<>();

        // After loading inputs, compute c using Lagrange Interpolation
        // System.out.println("Secret 1: " + computeLagrange(...));
        // System.out.println("Secret 2: " + computeLagrange(...));
    }

    // public static BigInteger computeLagrange(...) {
    //     // Implement Lagrange Interpolation here using BigInteger
    //     return BigInteger.ZERO; // Placeholder
    // }
}