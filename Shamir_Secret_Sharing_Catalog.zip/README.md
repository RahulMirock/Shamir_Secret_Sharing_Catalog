# Shamir Secret Sharing - Catalog Assignment

## Files
- `ShamirSecretSharing.java`: Main class to process both test cases and print constants.
- `input1.json`: First test case input.
- `input2.json`: Second test case input.
- `output.txt`: Store output of both test cases.
- No external libraries used as per instructions.

## Instructions
1. Read `input1.json` and `input2.json` manually.
2. Parse and convert y values using given base.
3. Use Lagrange interpolation with BigInteger to compute the constant term `c`.
4. Save both results in `output.txt`.
5. Push this project to your GitHub repo and submit the link.